﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDRSharp.Common;

namespace SDRSharp.FFTpPlugin
{
    public class FFTpPlugin : ISharpPlugin
    {
        private const string _displayName = "FFTp";
        private ISharpControl _control;
        private FFTpPluginPanel _guiControl;

        public UserControl Gui
        {
            get { return _guiControl; }
        }

        public string DisplayName
        {
            get { return _displayName + " " + Utils.Version(); }
        }

        public void Close()
        {
        }

        public void Initialize(ISharpControl control)
        {
            _control = control;
            _guiControl = new FFTpPluginPanel(control);
        }
    }
}
