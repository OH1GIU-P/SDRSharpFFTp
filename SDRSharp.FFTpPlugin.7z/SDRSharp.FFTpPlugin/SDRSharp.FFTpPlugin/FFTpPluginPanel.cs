﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDRSharp.Common;

namespace SDRSharp.FFTpPlugin
{
    public partial class FFTpPluginPanel : UserControl
    {
        private Form _fftForm = null; 
        private Control _fftControl = null;
        private bool drawBitmap = false;
        private bool fDraw = true;

        public FFTpPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            buttonStart.Enabled = true;
            buttonStop.Enabled = false;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            drawBitmap = false;
            fDraw = true;
            bool showFFT = false;
            try
            {
                foreach (Control ctrl in this.ParentForm.Controls)
                {
                    if (ctrl.Name.Equals("centerPanel"))
                    {
                        _fftControl = ctrl;
                        showFFT = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                showFFT = false;
                MessageBox.Show(ex.Message);
            }
            if (showFFT)
            {
                buttonStart.Enabled = false;
                buttonStop.Enabled = true;
                drawBitmap = true;
                _fftForm = new FFTpWindow();
                _fftForm.Show();
                timerFFTp.Enabled = true;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            drawBitmap = false;
            timerFFTp.Enabled = false;
            _fftForm.Close();
            _fftForm = null;
            buttonStop.Enabled = false;
            buttonStart.Enabled = true;
        }

        private void timerFFTp_Tick(object sender, EventArgs e)
        {
            if (drawBitmap)
            {
                Bitmap bitmap = new Bitmap(_fftControl.Width, _fftControl.Height);
                _fftControl.DrawToBitmap(bitmap, new Rectangle(0, 0, _fftControl.Width, _fftControl.Height));
                bitmap.MakeTransparent();
                if (!fDraw)
                {
                    Bitmap fftFormBitmap = new Bitmap(_fftForm.BackgroundImage);
                    Graphics g = Graphics.FromImage(fftFormBitmap);
                    g.DrawImage(bitmap, 0, 0);
                    _fftForm.BackgroundImage = fftFormBitmap;
                }
                else
                {
                    fDraw = false;
                    _fftForm.Width = bitmap.Width + 16;
                    _fftForm.Height = bitmap.Height + 48;
                    _fftForm.BackgroundImage = bitmap;
                }
            }
        }

    }
}
